export type UpdateUserData = {
  email?: string;
  password?: string;
  name?: string;
  refreshToken?: string | null;
};

export type SignUpData = {
  email: string;
  password: string;
  name: string;
};

export type CreateEventData = {
  hostId: number;
  title: string;
  dates: Date[];
  startTime: number;
  endTime: number;
};

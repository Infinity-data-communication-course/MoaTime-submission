export type CreateAvailableTimeData = {
  eventJoinId: number;
  date: Date;
  startTime: number;
  endTime: number;
};

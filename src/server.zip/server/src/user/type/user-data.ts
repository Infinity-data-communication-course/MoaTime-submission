export type UserData = {
  id: number;
  email: string;
  name: string;
};

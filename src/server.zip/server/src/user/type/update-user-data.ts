export type UpdateUserData = {
  email: string;
  name: string;
};

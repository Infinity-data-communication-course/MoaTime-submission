-- AlterTable
ALTER TABLE "user" ADD COLUMN     "refresh_token" TEXT;

MoaTime - gather team members at the same time
